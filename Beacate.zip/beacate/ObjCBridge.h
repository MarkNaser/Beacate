//
//  ObjCBridge.h
//  beacate
//
//  Created by Amr  Naser  on 2/7/17.
//  Copyright © 2017 Amr  Naser . All rights reserved.
//

#ifndef ObjCBridge_h
#define ObjCBridge_h

#import "EILIndoorSDK.h"
#import <EstimoteSDK/EstimoteSDK.h>
#import <EstimoteSDK/ESTRequestBeaconDetails.h>



#endif /* ObjCBridge_h */
